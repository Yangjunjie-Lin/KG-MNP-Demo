#!/usr/bin/env python3
"""核对交接说明包完整性及上游样例的文件、摘要、来源引用与定位。"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import sys
from pathlib import Path, PurePosixPath


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def check(root: Path) -> dict:
    base = root / "upstream"
    require(base.is_dir(), "缺少 upstream/ 目录")
    files = {}
    for path in base.rglob("*"):
        require(not path.is_symlink(), "输入目录不接受符号链接")
        if path.is_file():
            files[path.relative_to(base).as_posix()] = path.read_bytes()
    docs = {name: json.loads(raw.decode("utf-8-sig")) for name, raw in files.items() if name.endswith(".json")}
    manifest = docs["manifest.json"]
    names = set()
    for row in manifest["files"]:
        name = row["path"]
        parts = PurePosixPath(name)
        require(not parts.is_absolute() and ".." not in parts.parts and "\\" not in name, "清单含非法路径")
        require(name not in names, "清单含重复文件")
        names.add(name)
        require(name in files, "缺少清单文件：" + name)
        require(len(files[name]) == row["size_bytes"], "文件长度不符：" + name)
        require(sha(files[name]) == row["sha256"], "文件摘要不符：" + name)
    require(names == set(files) - {"manifest.json"}, "实际文件与清单不一致")
    allowed = manifest["generation_allowlist"]
    private = manifest["evaluator_only_files"]
    require(len(allowed) == len(set(allowed)), "生成白名单重复")
    require(set(allowed).issubset(files), "生成白名单指向不存在文件")
    require(set(private).issubset(files), "验收清单指向不存在文件")
    require(not set(allowed).intersection(private), "验收材料误入生成白名单")
    require(not any("acceptance_private" in PurePosixPath(n).parts for n in allowed), "验收目录不得供生成读取")
    locator = docs["source_locator.json"]
    sources = {s["source_id"]: s for s in locator["sources"]}
    evidence = {e["evidence_id"]: e for e in locator["evidence"]}
    require(len(sources) == len(locator["sources"]) and len(evidence) == len(locator["evidence"]), "来源或证据编号重复")
    records = {r["record_id"]: r for r in docs["records.json"]["records"]}
    texts = {t["text_id"]: t for t in docs["text_blocks.json"]["text_blocks"]}
    for name in ("records.json", "text_blocks.json", "quality_report.json"):
        doc = docs[name]
        require(doc["dataset_id"] == manifest["dataset_id"], "批次不一致：" + name)
        require(doc.get("snapshot_version", manifest["snapshot_version"]) == manifest["snapshot_version"], "快照版本不一致：" + name)
    for source in sources.values():
        require(source["file"] in allowed, "来源不在生成允许清单")
        require(sha(files[source["file"]]) == source["sha256"], "来源摘要不符")
        require(bool(source["source_version"] and source["access"]["permission_basis"]), "缺少版本或访问依据")
    for item in [*records.values(), *texts.values()]:
        require(item["source_ref"] in sources and item["evidence_ref"] in evidence, "来源或证据引用缺失")
        require(evidence[item["evidence_ref"]]["source_ref"] == item["source_ref"], "记录的证据来源不一致")
    for ev in evidence.values():
        source = sources[ev["source_ref"]]
        raw_text = files[source["file"]].decode("utf-8-sig")
        loc = ev["locator"]
        if loc["kind"] in {"record", "record_field"}:
            record = records[loc["record_id"]]
            require(record["source_ref"] == ev["source_ref"] and record["collection"] == loc["collection"], "记录定位来源不一致")
            matches = [r for r in csv.DictReader(io.StringIO(raw_text)) if all(r.get(k) == v for k,v in loc["primary_key"].items())]
            require(len(matches) == 1, "CSV 主键未唯一定位")
            require(all(record.get(k) == v for k,v in matches[0].items()), "表格数据与来源值不一致")
            if loc["kind"] == "record_field":
                require(record["field_evidence_refs"].get(loc["field"]) == ev["evidence_id"], "字段证据引用不一致")
        elif loc["kind"] == "char_range":
            text = texts[loc["text_id"]]
            start, end = loc["start"], loc["end"]
            require(type(start) is int and type(end) is int and 0 <= start < end <= len(raw_text), "字符区间无效")
            require(raw_text[start:end] == ev["quote"], "逐字引文定位不一致")
            require(text["text_version"] == loc["text_version"] and text["source_ref"] == ev["source_ref"], "文本版本或来源不一致")
            require(sha(text["text"].encode("utf-8")) == text["content_sha256"], "文本摘要不一致")
            position = text["source_position"]
            require(raw_text[position["start"]:position["end"]] == text["text"], "正文与来源区间不一致")
        else:
            raise ValueError("文件核对器不支持该定位类型")
    for row in docs["quality_report.json"]["checked_files"]:
        require(sha(files[row["path"]]) == row["sha256"], "质量报告绑定已失效")
    lock = docs["imports.lock.json"]
    for role in ("baseline", "companion_shapes"):
        item = lock[role]
        require(sha(files[item["file"]]) == item["sha256"], "基线或约束摘要不符")
    require(lock["license"]["file"] in files, "许可附件缺失")
    return {
        "status": "PASS",
        "scope": "FILES_HASHES_AND_LOCATORS_ONLY",
        "files_including_manifest": len(files),
        "source_snapshots": len(sources),
        "evidence_records": len(evidence),
        "evaluator_files_excluded_from_generation": True,
        "native_ingestion": "NOT_RUN",
        "business_review": "NOT_RUN",
        "semantic_validation": "NOT_RUN"
    }


def check_documentation(root: Path) -> dict:
    """Check documentation bytes only; this is not a runtime acceptance test."""
    root = root.resolve()
    index_path = root / "package_index.json"
    require(index_path.is_file(), "缺少说明包完整性索引 package_index.json")
    index = json.loads(index_path.read_text(encoding="utf-8"))
    require(index.get("package_kind") == "HANDOFF_DOCUMENTATION", "说明包类型不符")
    listed = set()
    for row in index["files"]:
        name = row["path"]
        p = PurePosixPath(name)
        require(not p.is_absolute() and ".." not in p.parts and "\\" not in name, "说明包索引含非法路径")
        require(name not in listed and name != "package_index.json", "说明包索引重复或循环引用")
        listed.add(name)
        file = root / name
        require(file.is_file() and not file.is_symlink(), "说明包文件缺失或为链接：" + name)
        require(file.resolve().is_relative_to(root), "说明包路径越界")
        raw = file.read_bytes()
        require(len(raw) == row["size_bytes"], "说明包文件长度不符：" + name)
        require(sha(raw) == row["sha256"], "说明包文件摘要不符：" + name)
    actual = set()
    for file in root.rglob("*"):
        require(not file.is_symlink(), "说明包不接受符号链接")
        if file.is_file():
            actual.add(file.relative_to(root).as_posix())
    require(actual == listed | {"package_index.json"}, "说明包索引与实际文件不一致")
    return {
        "status": "PASS",
        "scope": "DOCUMENTATION_FILE_INTEGRITY_ONLY",
        "files_including_index": len(actual),
        "runtime_artifacts_included": False,
        "runtime_contract_validation": "NOT_RUN",
        "external_collection": "NOT_RUN"
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    try:
        result = {
            "status": "PASS",
            "documentation": check_documentation(args.root),
            "upstream_example": check(args.root)
        }
    except (ValueError, KeyError, OSError, TypeError) as exc:
        print(json.dumps({"status":"FAIL", "reason":str(exc)}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
