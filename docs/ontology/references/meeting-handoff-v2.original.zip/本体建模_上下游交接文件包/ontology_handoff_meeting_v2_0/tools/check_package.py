#!/usr/bin/env python3
"""Read-only checks for this meeting example; not the production importer.

Python 3.10+, rdflib. pyshacl is optional: absence is reported as NOT_RUN.
No model calls, approvals, business actions, or automatic dependency downloads.
"""
from __future__ import annotations
import argparse, copy, csv, hashlib, io, json, re, shutil, sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
import rdflib
from rdflib import Graph, URIRef, Literal, RDF, XSD, Namespace
from rdflib.compare import isomorphic

EX = Namespace('https://example.org/ontology/')
SH = Namespace('http://www.w3.org/ns/shacl#')

def canonical(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

def digest(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def safe(root, relative):
    rel = PurePosixPath(relative)
    if rel.is_absolute() or '..' in rel.parts or '\\' in relative or ':' in relative:
        raise ValueError('UNSAFE_RELATIVE_PATH: ' + relative)
    root = Path(root).resolve()
    p = root.joinpath(*rel.parts)
    if p.is_symlink() or not p.resolve().is_relative_to(root): raise ValueError('PATH_ESCAPES_ROOT')
    if not p.is_file(): raise ValueError('MISSING_FILE: ' + relative)
    if p.stat().st_size > 10_000_000: raise ValueError('FILE_TOO_LARGE')
    return p

def load(path): return json.loads(Path(path).read_text(encoding='utf-8'))

def must(test, message):
    if not test: raise ValueError(message)

def files_check(root):
    root=Path(root); m=load(root/'manifest.json'); listed=m['files']
    must(len({r['path'] for r in listed})==len(listed),'DUPLICATE_FILE_DECLARATION')
    for r in listed:
        p=safe(root,r['path']); must(digest(p)==r['sha256'],'DIGEST_MISMATCH: '+r['path'])
        must(p.stat().st_size==r['size_bytes'],'SIZE_MISMATCH')
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'manifest.json'}
    must(actual=={r['path'] for r in listed},'INCOMPLETE_MANIFEST')
    return {'files':len(listed),'self_digest_excluded':True}

def sources_check(root):
    root=Path(root); data=load(root/'source_locator.json'); sources={s['source_id']:s for s in data['sources']}; evidence={}
    for s in sources.values():must(digest(safe(root,s['file']))==s['sha256'],'SOURCE_HASH_MISMATCH')
    for ev in data['evidence']:
        must(ev['evidence_id'] not in evidence,'DUPLICATE_EVIDENCE_ID')
        loc=ev['locator']; p=safe(root,sources[ev['source_ref']]['file']); text=p.read_text(encoding='utf-8')
        if loc['kind']=='char_range':
            must(loc['position_unit']=='Unicode code point' and loc['interval']=='[start,end)','POSITION_CONTRACT')
            must(0 <= loc['start'] <= loc['end'] <= len(text),'OFFSET_RANGE')
            must(text[loc['start']:loc['end']]==ev['quote'],'QUOTE_MISMATCH')
            observed=ev['quote']
        else:
            rows=list(csv.DictReader(io.StringIO(text)))
            rows=[r for r in rows if all(r.get(k)==v for k,v in loc['primary_key'].items())]
            must(len(rows)==1,'SOURCE_KEY_NOT_UNIQUE')
            observed=rows[0][loc['field']] if loc['kind']=='record_field' else rows[0]
        evidence[ev['evidence_id']]={'source_ref':ev['source_ref'],'kind':loc['kind'],'observed':observed}
    return sources,evidence

def input_check(root):
    root=Path(root); records=load(root/'records.json'); text=load(root/'text_blocks.json'); sources,ev=sources_check(root)
    tables={}
    for row in records['records']:
        must(row['source_ref'] in sources and row['evidence_ref'] in ev,'MISSING_RECORD_EVIDENCE')
        keyfield='employee_id' if row['collection']=='employees' else 'department_id'
        must(isinstance(row[keyfield],str) and bool(row[keyfield].strip()),'IDENTIFIER_NOT_STRING')
        group=tables.setdefault(row['collection'],{})
        must(row[keyfield] not in group,'DUPLICATE_BUSINESS_KEY');group[row[keyfield]]=row
        for field,eid in row['field_evidence_refs'].items():must(row[field]==ev[eid]['observed'],'FIELD_SOURCE_MISMATCH')
    for row in tables['employees'].values():must(row['department_id'] in tables['departments'],'UNRESOLVED_DEPARTMENT')
    for b in text['text_blocks']:
        must(hashlib.sha256(b['text'].encode()).hexdigest()==b['content_sha256'],'TEXT_HASH_MISMATCH')
        must(b['text']==ev[b['evidence_ref']]['observed'],'TEXT_SOURCE_MISMATCH')
    return {'records':len(records['records']),'text_blocks':len(text['text_blocks']),'sources':len(sources),'evidence':len(ev)}

def baseline_check(root):
    root=Path(root); lock=load(root/'imports.lock.json')
    for item in [lock['baseline'],lock['companion_shapes']]:
        p=safe(root,item['file']); b=p.read_bytes()
        must(digest(p)==item['sha256'],'BASELINE_DIGEST')
        must(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==item['git_blob_sha'],'PINNED_GIT_BLOB_MISMATCH')
    must(lock['imports']==[],'UNEXPECTED_IMPORTS_IN_THIS_EXAMPLE')
    return {'pinned_commit':lock['domain_pack']['repository_commit'],'byte_verified_resources':2}

def public_check(root):
    root=Path(root); m=load(root/'manifest.json')
    must(not(set(m['generation_allowlist']) & set(m['evaluator_only_files'])),'GOLD_ALLOWLIST_OVERLAP')
    goals=load(root/'goal_and_rules.json')
    must('acceptance_baseline' not in goals and 'expected_department_id' not in goals,'ANSWER_IN_PUBLIC_GOALS')
    for rel in m['generation_allowlist']:
        must('acceptance_private' not in PurePosixPath(rel).parts,'PRIVATE_FILE_ALLOWED');safe(root,rel)
    return {'allowed_files':len(m['generation_allowlist']),'private_files_excluded':m['evaluator_only_files'],'os_sandbox':'NOT_IMPLEMENTED_BY_THIS_MEETING_PACKAGE'}

def map_graph(down):
    down=Path(down); mapping=load(down/'mapping.json'); fragment=mapping['native_request_fragment']
    must(set(fragment)=={'profile','tables'} and fragment['profile']=='evidence-record-mapping-v1','MAPPING_FRAGMENT_CONTRACT')
    records=load(safe(down,mapping['source_file']))['records']; tables=fragment['tables']; index={}; graph=Graph()
    for table in tables:
        must(set(table)=={'table_id','source_name','class_iri','id_field','literals','references'},'TABLE_FIELDS')
        rows=[r for r in records if r['collection']==table['table_id']]; index[table['table_id']]={}
        for row in rows:
            key=row[table['id_field']]; must(isinstance(key,str) and bool(key.strip()),'EMPTY_ID')
            must(key not in index[table['table_id']],'DUPLICATE_ID');index[table['table_id']][key]=row
    for table in tables:
        for key,row in index[table['table_id']].items():
            s=EX[key];graph.add((s,RDF.type,URIRef(table['class_iri'])))
            for field,p in table['literals'].items():graph.add((s,URIRef(p),Literal(row[field],datatype=XSD.string)))
            for ref in table['references']:
                must(set(ref)=={'field','target_table','predicate_iri'},'REFERENCE_FIELDS')
                value=row[ref['field']];must(value in index[ref['target_table']],'UNRESOLVED_REF')
                graph.add((s,URIRef(ref['predicate_iri']),EX[value]))
    return graph

def graph_check(down):
    d=Path(down); graph=Graph().parse(d/'instances.ttl',format='turtle'); expected=map_graph(d)
    must(isomorphic(expected,graph),'MAPPING_GRAPH_DIFF')
    must(isomorphic(graph,Graph().parse(data=graph.serialize(format='turtle'),format='turtle')),'RDF_ROUNDTRIP_DIFF')
    must((d/'ontology.ttl').read_bytes()==(d/'dependencies/baseline.ttl').read_bytes(),'FULL_BASELINE_NOT_PRESERVED')
    must((d/'shapes.ttl').read_bytes()==(d/'dependencies/assets/baseline_shapes.ttl').read_bytes(),'SHAPES_NOT_PRESERVED')
    for rel in ['ontology.ttl','shapes.ttl']:Graph().parse(d/rel,format='turtle')
    return {'instance_triples':len(graph),'mapped_triples':len(expected),'native_compiler_execution':'NOT_RUN'}

def triple(row):
    s,p,o=row['triple']
    obj=URIRef(o) if row['object_kind']=='iri' else Literal(o,datatype=URIRef(row['datatype']))
    return URIRef(s),URIRef(p),obj

def review_bound(down,review=None):
    d=Path(down); review=review or load(d/'review.json'); facts=[json.loads(l) for l in (d/'provenance.jsonl').read_text().splitlines() if l.strip()]
    by_id={r['review_id']:r for r in review['items']}
    for f in facts:
        r=by_id[f['review_ref']]
        if r['content_sha256']!=canonical(f) or r['candidate_version']!=f['candidate_version']:return False
    return all(digest(safe(d,r['artifact']))==r['content_sha256'] for r in review['artifact_reviews'])

def provenance_check(down):
    d=Path(down); graph=Graph().parse(d/'instances.ttl',format='turtle'); facts=[json.loads(l) for l in (d/'provenance.jsonl').read_text().splitlines() if l.strip()]
    _,ev=sources_check(d/'dependencies'); mapping={r['mapping_id'] for r in load(d/'mapping.json')['rules']}
    must(len({r['fact_id'] for r in facts})==len(facts),'DUPLICATE_FACT_ID')
    must({triple(r) for r in facts}==set(graph),'FACT_REGISTRY_GRAPH_DIFF')
    for r in facts:
        must(r['mapping_ref'] in mapping and bool(r['evidence_refs']),'MISSING_MAPPING_OR_EVIDENCE')
        for eid in r['evidence_refs']:must(eid in ev,'UNKNOWN_EVIDENCE')
    must(review_bound(d),'REVIEW_CONTENT_CHANGED')
    return {'facts':len(facts),'review_bindings':len(facts),'semantic_support_by_expert':'NOT_RUN'}

def exact_term(t):
    if t is None:return None
    must(t.get('kind') in {'IRI','LITERAL'},'BAD_RDF_TERM_KIND')
    if t['kind']=='IRI':must(not t.get('datatype') and not t.get('language'),'IRI_ANNOTATION');return URIRef(t['value']).n3()
    must(bool(t.get('datatype')) != bool(t.get('language')),'LITERAL_DATATYPE_OR_LANGUAGE_REQUIRED')
    return Literal(t['value'],datatype=URIRef(t['datatype']) if t.get('datatype') else None,lang=t.get('language')).n3()

def normalized(rows,comparison):
    lines=[json.dumps(r,sort_keys=True,ensure_ascii=False) for r in rows]
    if comparison=='SET':return sorted(set(lines))
    if comparison=='MULTISET':return sorted(lines)
    if comparison=='ORDERED':return lines
    raise ValueError('INVALID_COMPARISON')

def query_pass(down,graph):
    d=Path(down); test=load(d/'tests/cq_01.json'); expected=test['expected']
    must(expected['query_type']=='SELECT' and expected['comparison'] in {'SET','MULTISET','ORDERED'},'EXACT_ANSWER_CONTRACT')
    must(expected.get('boolean') is None,'SELECT_HAS_BOOLEAN')
    q=safe(d,test['query_file']).read_text()
    must(not re.search(r'\b(SERVICE|FROM|LOAD|INSERT|DELETE|DROP|CLEAR)\b',q,re.I),'NONLOCAL_QUERY')
    must(digest(safe(d,test['query_file']))==test['query_sha256'],'QUERY_CHANGED')
    if expected['comparison']=='ORDERED':must(bool(re.search(r'\bORDER\s+BY\b',q,re.I)),'ORDERED_WITHOUT_ORDER_BY')
    result=graph.query(q); variables=[str(v) for v in result.vars]
    actual=[{v:(row[i].n3() if row[i] is not None else None) for i,v in enumerate(variables)} for row in result]
    wanted=[{v:exact_term(r[v]) for v in expected['variables']} for r in expected['rows']]
    return variables==expected['variables'] and normalized(actual,expected['comparison'])==normalized(wanted,expected['comparison']),actual

def query_trace_check(down):
    d=Path(down); test=load(d/'tests/cq_01.json'); baseline=load(safe(d,test['baseline_file'])); case=next(x for x in baseline['cases'] if x['case_id']==test['baseline_case_id'])
    must(digest(safe(d,test['baseline_file']))==test['baseline_sha256'],'ORACLE_FILE_CHANGED')
    must(case['expected']==test['expected'] and canonical(test['expected'])==case['expected_content_sha256'],'ORACLE_COPY_CHANGED')
    for row in test['input_graphs']:must(digest(safe(d,row['path']))==row['sha256'],'QUERY_INPUT_CHANGED')
    graph=Graph().parse(d/'instances.ttl',format='turtle');ok,rows=query_pass(d,graph);must(ok,'QUERY_ANSWER_DIFF')
    exp=case['trace_expectation'];facts=[json.loads(l) for l in (d/'provenance.jsonl').read_text().splitlines() if l.strip()]
    fact=next(f for f in facts if f['triple']==[exp['subject'],exp['predicate'],case['expected']['rows'][0]['department']['value']])
    _,ev=sources_check(d/'dependencies');hits=[ev[eid] for eid in fact['evidence_refs']]
    must(len({h['source_ref'] for h in hits})>=exp['minimum_distinct_sources'],'TRACE_SOURCE_COUNT')
    must(set(exp['required_evidence_kinds']).issubset({h['kind'] for h in hits}),'TRACE_EVIDENCE_KINDS')
    return {'query_rows':rows,'comparison':test['expected']['comparison'],'trace_fact_id':fact['fact_id'],'trace_evidence':fact['evidence_refs'],'independent_expectation':'COPIED_FROM_V1_BEFORE_V2_BUILD; NOT_EXPERT_APPROVED'}

def coverage_ok(down,graph):
    needed={t for t in map_graph(down) if t[1]==RDF.type}
    return needed.issubset(set(graph))

def shacl_status(down,graph):
    try: import pyshacl
    except ImportError:return None
    conforms,_,_=pyshacl.validate(data_graph=graph,shacl_graph=Graph().parse(Path(down)/'shapes.ttl',format='turtle'),ont_graph=Graph().parse(Path(down)/'ontology.ttl',format='turtle'),inference='none',meta_shacl=True,advanced=False,js=False,do_owl_imports=False)
    return bool(conforms)

def negatives_check(down):
    d=Path(down); original=Graph().parse(d/'instances.ttl',format='turtle'); plan=load(d/'tests/negative_cases.json'); out=[]
    for case in plan['cases']:
        g=Graph();g+=original;review=copy.deepcopy(load(d/'review.json')); m=case['mutation'];rel=(EX['E-001'],EX.belongsToDepartment,EX['D-01'])
        if m=='REMOVE_RELATION':g.remove(rel)
        elif m=='UNKNOWN_DEPARTMENT':g.remove(rel);g.add((rel[0],rel[1],EX['D-99']))
        elif m=='REVERSE_RELATION':g.remove(rel);g.add((rel[2],rel[1],rel[0]))
        elif m=='TWO_DEPARTMENTS':
            g.add((EX['E-001'],EX.belongsToDepartment,EX['D-02']));g.add((EX['D-02'],RDF.type,EX.Department));g.add((EX['D-02'],EX.departmentId,Literal('D-02',datatype=XSD.string)));g.add((EX['D-02'],EX.departmentName,Literal('反例部门',datatype=XSD.string)))
        elif m=='REMOVE_EMPLOYEE_ID':g.remove((EX['E-001'],EX.employeeId,None))
        elif m=='EMPTY_RELATION_TARGET':g.remove(rel);g.add((rel[0],rel[1],Literal('',datatype=XSD.string)))
        elif m=='WRONG_IDENTIFIER_DATATYPE':g.remove((EX['E-001'],EX.employeeId,None));g.add((EX['E-001'],EX.employeeId,Literal(1,datatype=XSD.integer)))
        elif m=='REMOVE_EMPLOYEE_TYPE':g.remove((EX['E-001'],RDF.type,EX.Employee))
        elif m=='STALE_REVIEW_DIGEST':review['items'][0]['content_sha256']='0'*64
        else:raise ValueError('UNKNOWN_MUTATION')
        observations=[]
        for checker in case['checkers']:
            if checker=='QUERY_ASSERTION': accepted=query_pass(d,g)[0]
            elif checker=='SHACL':accepted=shacl_status(d,g)
            elif checker=='EXPLICIT_TARGET_COVERAGE':accepted=coverage_ok(d,g)
            elif checker=='REVIEW_CONTENT_BINDING':accepted=review_bound(d,review)
            else:raise ValueError('UNKNOWN_CHECKER')
            observations.append({'checker':checker,'status':'NOT_RUN' if accepted is None else ('PASS' if not accepted else 'FAIL'),'observed':'NOT_RUN_MISSING_PYSHACL' if accepted is None else ('REJECT' if not accepted else 'ACCEPT')})
        out.append({'test_id':case['test_id'],'name':case['name'],'checks':observations})
    return out

def export_generation(upstream,destination):
    u=Path(upstream); destination=Path(destination)
    must(not destination.exists(),'EXPORT_DESTINATION_MUST_NOT_EXIST'); m=load(u/'manifest.json');public_check(u);files_check(u)
    destination.mkdir(parents=True)
    for rel in m['generation_allowlist']:
        target=destination/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(safe(u,rel),target)
    return {'status':'EXPORTED_PUBLIC_FILES_ONLY','files':len(m['generation_allowlist']),'os_isolation':'NOT_CLAIMED','note':'只导出允许的示例文件；正式生成进程仍需独立挂载/权限或受控输入，不可访问原始整包。'}

def run(root=None,downstream=None,skip_manifest=False):
    d=Path(downstream).resolve() if downstream else Path(root).resolve()/'downstream'; rows=[]
    def collect(name,fn):
        try:rows.append({'check':name,'status':'PASS','detail':fn()})
        except Exception as exc:rows.append({'check':name,'status':'FAIL','error':str(exc)})
    if root:
        u=Path(root).resolve()/'upstream'
        if not skip_manifest:collect('UPSTREAM_FILE_MANIFEST',lambda:files_check(u))
        collect('UPSTREAM_INPUT_QUALITY',lambda:input_check(u));collect('GENERATION_INPUT_ALLOWLIST',lambda:public_check(u))
        collect('PINNED_BASELINE_BYTES',lambda:baseline_check(u))
    if not skip_manifest:
        collect('DOWNSTREAM_SELF_CONTAINED_MANIFEST',lambda:files_check(d));collect('FROZEN_UPSTREAM_SNAPSHOT',lambda:files_check(d/'dependencies'))
    collect('DOWNSTREAM_SOURCE_LOCATORS',lambda:input_check(d/'dependencies'))
    collect('RDF_AND_LOCAL_MAPPING_REPLAY',lambda:graph_check(d))
    collect('FACT_PROVENANCE_AND_REVIEW_BINDINGS',lambda:provenance_check(d))
    collect('TYPED_QUERY_AND_SOURCE_TRACE',lambda:query_trace_check(d))
    collect('EXPLICIT_TARGET_COVERAGE',lambda: {'target_objects':2,'matches':coverage_ok(d,Graph().parse(d/'instances.ttl',format='turtle'))} if coverage_ok(d,Graph().parse(d/'instances.ttl',format='turtle')) else (_ for _ in ()).throw(ValueError('MISSING_TARGET_TYPE')))
    normal_shacl=shacl_status(d,Graph().parse(d/'instances.ttl',format='turtle'))
    rows.append({'check':'PYSHACL','status':'NOT_RUN' if normal_shacl is None else ('PASS' if normal_shacl else 'FAIL'),'detail':{'inference':'none','reason':'pyshacl 未安装；未以自写检查冒充 SHACL' if normal_shacl is None else 'pyshacl.validate 真正运行'}})
    negatives=negatives_check(d)
    for name in ['OWL_PROFILE_HERMIT','NATIVE_SERVICE_IMPORT_EXPORT','LIVE_MODEL','REAL_HUMAN_APPROVAL','PRODUCTION_RELEASE']:
        rows.append({'check':name,'status':'NOT_RUN','detail':'不在本次会议示例本地执行范围'})
    flat=rows+[r for c in negatives for r in c['checks']];counts=Counter(x['status'] for x in flat)
    return {'report_kind':'MEETING_EXAMPLE_LOCAL_CHECK','checked_at':datetime.now(timezone.utc).isoformat(),'status':'FAIL' if counts['FAIL'] else 'LOCAL_CHECKS_PASS_WITH_NOT_RUN','full_production_acceptance':False,'runtime':{'python':sys.version.split()[0],'rdflib':rdflib.__version__},'checks':rows,'negative_cases':negatives,'summary':dict(counts),'note':'PASS 仅覆盖对应本地检查；反例 PASS 表示错误已被发现。未运行项、待审核和未发布状态不能自动变为通过。'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--downstream',type=Path);p.add_argument('--report',type=Path);p.add_argument('--export-generation',type=Path);args=p.parse_args()
    try:
        report=export_generation(args.root/'upstream',args.export_generation) if args.export_generation else run(None if args.downstream else args.root,args.downstream)
        raw=json.dumps(report,ensure_ascii=False,indent=2)+'\n'
        if args.report:
            if args.report.exists():raise ValueError('REPORT_EXISTS_REFUSE_OVERWRITE')
            args.report.parent.mkdir(parents=True,exist_ok=True);args.report.write_text(raw,encoding='utf-8')
        print(raw)
        return 1 if report.get('status')=='FAIL' else 0
    except Exception as exc:
        print(json.dumps({'status':'ERROR','error':str(exc)},ensure_ascii=False));return 2
if __name__=='__main__':raise SystemExit(main())
