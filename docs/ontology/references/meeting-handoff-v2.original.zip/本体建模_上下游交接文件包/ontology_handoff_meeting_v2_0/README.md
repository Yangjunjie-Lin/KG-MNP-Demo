# 本体建模上下游交接 · 修订会议版 v2.0

先打开 **index.html**。点击清单中的文件名查看“用途、提供方、必需内容、例子”。Word 版为 meeting_guide.docx。

本版保留员工 E-001 属于部门 D-01 的同一例子；上游及配套共 9 项主文件，下游仍为 11 项主文件。sources、assets、dependencies 是依赖附件，不再另列成主业务文件。

## 相对 v1 的调整

| 调整 | 文件 |
|---|---|
| 交接批次与真实运行引用，不再把几个孤立 JSON 当原生输入包 | 新增 upstream/manifest.json；真实运行标识留 null |
| 目标规则和隐藏答案拆开 | goal_and_rules.json；新增 acceptance_private/expected_answers.json |
| 完整保留固定 HR 定义、配套 shapes、版本与许可 | baseline.ttl、imports.lock.json、assets/ |
| 下游独立可交接，没有 ../upstream 路径依赖 | downstream/dependencies/ |
| 对齐 SET 与类型化 RDF 答案，补充来源回查 | tests/cq_01.json 与同一份冻结预期 |
| 补齐结构、约束、映射、范围和答案的审核摘要绑定 | review.json |

## 谁负责提供

清洗模块提供记录、文本、来源、质量及批次封面；业务方提供并确认目标与规则；平台方提供可选基线；验收方独立给出答案。
范围审批、候选、编译计划是本体建模内部工件，不能要求清洗方预制。

## 三种格式不混用

此包是建议交换约定与可重跑的会议样例，不是原始 v3 Schema，也不是原生 .kgop。

现有项目路径为 Source/Batch/Plan/Run → KG-IR/Evidence → modeling.session → 原生编译 → .kgop/Registry。正式接入需要薄适配与真实服务端运行。

- mapping.json 的 native_request_fragment 只对齐 RecordMappingRequest 的 profile/tables 字段；整个文件不是 DTO，也不是编译后 MappingPlan。
- tests/cq_01.json 的 expected 子对象对齐 ExactAnswer；查询资产尚未登记，query_asset_id 留 null，另列建议 ID。
- run_id、project_id、编译快照、审核头等不伪造。实例 IRI 沿用页面可读示例，原生 ID 仍由现有身份内核生成。
- baseline/ontology/shapes 使用 hr@0.1.0；2.0.0 是本次交换包版本，不是冒改原 HR 本体版本。

## 生成侧不能读取验收答案

此完整包及 index.html 含示例答案，供获授权会议/验收人员阅读，不用于整包喂给模型。
上游答案在 acceptance_private/；下游固定副本在 dependencies/acceptance_private/，测试也是验收材料。
可用工具仅复制 manifest 中列明的 generation_allowlist：

```powershell
python tools/check_package.py --export-generation ..\generation_only_v2
```

输出目录必须不存在。该工具只做受控文件导出，不构成 OS 沙箱；生产运行还应限制进程挂载、文件权限或 broker 输入。
答案语义继承上传 v1 的预期，先于本次图生成/查询固定；不是从 v2 输出反推，也不是已获真实专家批准。

## 下游可独立拷出

将整个 downstream/ 拷出即可得到本例所需的依赖与合成原件。该部分已在没有上游目录的独立副本中检查。
不要删除 dependencies/；默认查询只使用 instances.ttl，约束、溯源、审核、测试不并入业务图。
依赖复制仅针对此次用户提供的合成例子，不意味着真实业务资料有复制或再分发许可。

## 检查和复现

本次报告在 check_report.json；下游 validation.json 绑定了受测文件和局部结果。

```powershell
python tools/check_package.py
# 下游单独交接后，可在保留本工具的机器上复验：
python tools/check_package.py --downstream "路径\downstream"
# 保存新检查记录时，目标文件必须不存在：
python tools/check_package.py --report ..\handoff_check_v2.json
```

需要 Python 3.10+、rdflib；本次 rdflib 版本记录在报告内。已有 pyshacl 时自动运行其验证；缺少时明确 NOT_RUN，不自动下载。
本脚本针对本例，不是通用不可信上传验证器，不修改数据、请求模型、替代人工批准或发布。

实际执行了输入/来源摘要与定位、固定 Git blob、图与本地映射重建、事实溯源、类型覆盖、查询与来源回查、可运行的反例。
9 类反例计划已经给出；本次仅运行可用检查器，SHACL 项未运行，不能把全部反例计划声称为已通过。
pySHACL、OWL Profile/HermiT、原生导入导出、真实模型、人工审批与发布未执行。因此状态为 PARTIAL_VALIDATION / PENDING_REVIEW / NOT_RELEASED。

## 依据与范围

直接依据：用户上传的会议包 v1、preview2(1).html 的输入/交付组织，以及上一轮已确认的“会议包复核与最小调整清单”。
本轮重新读取以下固定提交资源，并用 Git blob SHA 校验复制的 TTL 原字节：

- https://github.com/Yangjunjie-Lin/KG-MNP-Demo/blob/194e091d13cabba5833ff1d531f814858ea968ae/domain_packs/hr/ontology/hr.ttl
- https://github.com/Yangjunjie-Lin/KG-MNP-Demo/blob/194e091d13cabba5833ff1d531f814858ea968ae/domain_packs/hr/shapes/hr.ttl
- https://github.com/Yangjunjie-Lin/KG-MNP-Demo/blob/194e091d13cabba5833ff1d531f814858ea968ae/src/zhigou_toolchain/modeling/five_stage/exact_answers.py

请求与流程边界沿用上一轮同一提交审阅的 services/requests.py、docs/upgrade/module-contracts.md 和原生 package manifest Schema。本轮不声称检查了此提交之后的变更，也没有修改仓库。
员工—部门只说明本体交接方法；本包不声称覆盖古树巡查、真实政务数据或外部 benchmark 的完整业务/研究验收。
